<?php
// config/mail.php
return [
    'host' => 'smtp.gmail.com',
    'port' => 587,
    'username' => 'cyberdukanofficial@gmail.com',
    'password' => 'fhnmfttjqpjlxlzt', // Generate this in Google Account > Security
    'from_email' => 'cyberdukanofficial@gmail.com',
    'from_name' => 'SAHARA Society'
];