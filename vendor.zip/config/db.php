<?php
$servername = "193.203.184.3";
$username = "u214833083_adityakumar";
$password = "Sahi@8102";
$database = "u214833083_adityakumar"; // 🔁 Change this to your actual database name

// Enable error reporting for debugging (Remove this when moving back to live)
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $conn = new mysqli($servername, $username, $password, $database);
    
    // Set charset to utf8mb4 for better compatibility
    $conn->set_charset("utf8mb4");
    $conn->query("SET time_zone = '+05:30'");
    // Timezone
    date_default_timezone_set('Asia/Kolkata');
    

} catch (Exception $e) {
    // If it fails, send a JSON response so your frontend doesn't crash with HTML
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false, 
        'message' => 'Database connection failed: ' . $e->getMessage()
    ]);
    exit;
}
?>
